# Keycloak Kubernetes Deployment Guide

## **Kubernetes Environment Pre-Requisites**
1. Helm
2. Ingress
3. Persistent storage ( default storage class set)<br>

## Keycloak Overview
### Keycloak is an open source identity and access management for modern applications and services.

### Prerequisites Details
The keycloak has an optional dependency on the PostgreSQL.

### Deploying POSTGRESQL

### Clonning the repository
````
jiocloud@k8s13:~$ sudo -
root@k8s13:~# source proxy # A source file with proxy variables is stored in the root user's home directory. You can also export proxy settings manually.
root@k8s13:~# env | grep proxy
http_proxy=http://10.144.106.132:8678
https_proxy=http://10.144.106.132:8678
root@k8s13:~# git clone https://gitlab.com/jioaws/jaws-apps-k8s-deployment # Needs proxy set
root@k8s13:~# cd jaws-apps-k8s-deployment/keycloak
````
### Deploying POSTGRESQL
```
root@k8s13:~/jaws-apps-k8s-deployment/# helm install --name postgresql --namespace keycloak -f postgresql/production-postgresql.yaml stable/postgresql
...
NOTES:
** Please be patient while the chart is being deployed **

PostgreSQL can be accessed via port 5432 on the following DNS name from within your cluster:

    postgresql-postgresql.keycloak.svc.cluster.local - Read/Write connection
    postgresql-postgresql-read.keycloak.svc.cluster.local - Read only connection
To get the password for "keycloak" run:

    export POSTGRES_PASSWORD=$(kubectl get secret --namespace keycloak postgresql-postgresql -o jsonpath="{.data.postgresql-password}" | base64 --decode)

To connect to your database run the following command:

    kubectl run postgresql-postgresql-client --rm --tty -i --restart='Never' --namespace keycloak --image docker.io/bitnami/postgresql:10.7.0 --env="PGPASSWORD=$POSTGRES_PASSWORD" --command -- psql --host postgresql-postgresql -U keycloak -d keycloak



To connect to your database from outside the cluster execute the following commands:

    kubectl port-forward --namespace keycloak svc/postgresql-postgresql 5432:5432 &
    PGPASSWORD="$POSTGRES_PASSWORD" psql --host 127.0.0.1 -U keycloak -d keycloak
```

### **Note: Read/Write Connection DNS will be needed for keycloak to communicate with postgresql**

### Optionally Change RECLAIM Policy from Delete to Retain 
```
root@k8s13:~/jaws-apps-k8s-deployment/# kubectl get pv

pvc-a2e241d3-6727-11e9-b598-027f39c7f4f9   100Gi      RWO            Delete           Bound    keycloak/data-postgresql-postgresql-slave-0    gold                    4m22s
pvc-a32fe278-6727-11e9-b598-027f39c7f4f9   100Gi      RWO            Delete           Bound    keycloak/data-postgresql-postgresql-master-0   gold                    4m21s
pvc-c49e29b9-6727-11e9-b598-027f39c7f4f9   100Gi      RWO            Delete           Bound    keycloak/data-postgresql-postgresql-slave-1    gold                    3m22s

root@k8s13:~/jaws-apps-k8s-deployment/# kubectl patch pv pvc-a2e241d3-6727-11e9-b598-027f39c7f4f9 -p '{"spec":{"persistentVolumeReclaimPolicy":"Retain"}}'
root@k8s13:~/jaws-apps-k8s-deployment/# kubectl patch pv pvc-a32fe278-6727-11e9-b598-027f39c7f4f9  -p '{"spec":{"persistentVolumeReclaimPolicy":"Retain"}}'
root@k8s13:~/jaws-apps-k8s-deployment/# kubectl patch pv pvc-c49e29b9-6727-11e9-b598-027f39c7f4f9  -p '{"spec":{"persistentVolumeReclaimPolicy":"Retain"}}'
root@k8s13:~/jaws-apps-k8s-deployment/# kubectl get pv

pvc-a2e241d3-6727-11e9-b598-027f39c7f4f9   100Gi      RWO            Retain           Bound    keycloak/data-postgresql-postgresql-slave-0    gold                    4m22s
pvc-a32fe278-6727-11e9-b598-027f39c7f4f9   100Gi      RWO            Retain           Bound    keycloak/data-postgresql-postgresql-master-0   gold                    4m21s
pvc-c49e29b9-6727-11e9-b598-027f39c7f4f9   100Gi      RWO            Retain           Bound    keycloak/data-postgresql-postgresql-slave-1    gold                    3m22s


```

### Create SSL/TLS certs for your keycloak ingress
```
root@k8s13:~/jaws-apps-k8s-deployment/# mkdir $HOME/certs
root@k8s13:~/jaws-apps-k8s-deployment/# cd $HOME/certs
root@k8s13:~/jaws-apps-k8s-deployment/# openssl genrsa -out tls.key 2048
root@k8s13:~/jaws-apps-k8s-deployment/# openssl rsa -in tls.key -out tls.key
root@k8s13:~/jaws-apps-k8s-deployment/# openssl req -sha256 -new -key tls.key -out tls.csr -subj '/CN=login.jaws.jio.com'
root@k8s13:~/jaws-apps-k8s-deployment/# openssl x509 -req -sha256 -days 3650 -in tls.csr -signkey tls.key -out tls.crt
```

### Register tls certs for keycloak as secret 
```
root@k8s13:~/jaws-apps-k8s-deployment/# kubectl -n keycloak create secret generic tls-keycloak --from-file=$HOME/certs
```
### Update keycloak.yaml  with Read/Write Connection DNS of postgresql for dbHost value (if you have changed dbHost and Port)
```
root@k8s13:~/jaws-apps-k8s-deployment/# vim keycloak/keycloak.yaml
...
    dbName: xxxxxxxx
    dbHost: postgresql-postgresql.keycloak.svc.cluster.local  # Need to be replace
    dbPort: 5432 # 5432 is PostgreSQL's default port. For MySQL it would be 3306
    dbUser: xxxxxxx
...
```
### Deploying Keycloak
#### Pull the theme container into each worker node (Mandatory, as keycloak helm chart does not allow specifying registry secret to pull images yet)
```
(worker1/2/3)# docker pull registry.gitlab.com/jioaws/jaws-keycloak-theme:master
master: Pulling from jioaws/jaws-keycloak-theme
fc1a6b909f82: Pull complete
c913c855c287: Pull complete
da56b0a02dac: Pull complete
ddf7da9cac14: Pull complete
59541fb59477: Pull complete
Digest: sha256:e120db2d89718eb1c6b538e35919f5f6d701c322d50d6d8d4fdac177226c5fe1
Status: Downloaded newer image for registry.gitlab.com/jioaws/jaws-keycloak-theme:master
```

```
root@k8s13:~/certs/# cd $HOME/jaws-apps-k8s-deployment/keycloak/
root@k8s13:~/jaws-apps-k8s-deployment/keycloak# helm install --name keycloak --namespace keycloak -f keycloak/keycloak.yaml stable/keycloak
```

### Deploying JAWS SSO Realm
1. Login to Keycloak UI using admin credentials.
2. Hover above "Master" on top left, and click "Add realm".
3. Import "sso.json" file under ssorealm/sso.json.
4. Change the HTML display name of the realm as "JAWS SSO Realm"
5. Under "Themes", select "jaws" as Login Theme, and Save.
6. Go to "User Federation">ldap, verify the ldap Connection URL and click Test connection. It should show you "Success! LDAP connection successful" on top.
7. Then perform a binding test by entering password "P@ssw0rd!@#" (without the quotes) into "Bind Credential", and click "Test connection". The password is the Active directory password for user "jaws.sso".
