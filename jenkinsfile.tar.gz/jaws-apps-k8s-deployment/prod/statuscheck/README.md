This document describes the procedure for deploying status check infrastructure.
This includes telegraf agents installed on VMs, HAProxy endpoints, Kafka clusters
for nonprod and prod VMs, consumers and InfluxDB.

Reference document: <https://docs.google.com/document/d/1NDeAU1Ice7q0pmfshjgPnLnPEkPdkBYZh-psPy9p1i0/edit?usp=sharing>

## Telegraf agent installation on VMs

Telegraf agents are installed using Heat template scripts executed by JAWS console.
These are stored in this git repo: <https://github.com/mayankkapoor/HeatTemplates>.
The telegraf agents are configured using a conf file, which is separate for
nonprod and prod VMs. The conf files are stored in this git repo:
<https://github.com/mayankkapoor/statuscheck>

## Shut down HAProxy & NGINX endpoints for Kafka

Before deploying Kafka clusters, it is very important to shut down the HAProxy
endpoints by shutting down HAProxy service. If we don't do this, the producers
(telegraf agents installed on VMs) will create the "telegraf" topic on our
Kafka clusters as soon as they connect, setting the # of partitions and
Replication Factor incorrectly. If you shut down HAProxy service, the "telegraf"
topic will be initialized incorrectly during deployment.

## Create Kafka clusters using helm charts.

All commands executed as root with kubectl configured, and on k8s master.

Create the kafka cluster for nonprod vms inside new namespace kafkaprod-nonprodvm:

    # git clone https://gitlab.com/jioaws/jaws-apps-k8s-deployment # This git repo
    # git clone https://github.com/helm/charts.git # To lock down kafka helm chart version locally
    # helm repo add incubator https://kubernetes-charts-incubator.storage.googleapis.com/
    # helm repo update
    # cd charts/incubator/kafka
    # helm dependency update
    # cd ~
    # helm install -f jaws-apps-k8s-deployment/prod/statuscheck/kafka/values_nonprod.yaml --name kafkaprod-nonprodvm --namespace kafkaprod-nonprodvm charts/incubator/kafka/

Create the kafka cluster for prod vms inside new namespace kafkaprod-prodvm:

    # helm install -f jaws-apps-k8s-deployment/prod/statuscheck/kafka/values_prod.yaml --name kafkaprod-prodvm --namespace kafkaprod-prodvm charts/incubator/kafka/

## Deploy Kafka-managers clusters using helm charts.

    # helm install -f jaws-apps-k8s-deployment/prod/statuscheck/kafka-manager/values_nonprod.yaml --name kafka-manager-nonprod --namespace kafkaprod-nonprodvm stable/kafka-manager
    # helm install -f jaws-apps-k8s-deployment/prod/statuscheck/kafka-manager/values_prod.yaml --name kafka-manager-prod --namespace kafkaprod-prodvm stable/kafka-manager

## Verify kafka partitions and brokers
Log into kafka managers and verify telegraf topic has 60 partitions and 3 brokers. Delete the topic and recreate it if necessary.
```
Topic	# Partitions	# Brokers	Brokers Spread %	Brokers Skew %	Brokers Leader Skew %	# Replicas	Under Replicated %	Producer Message/Sec	Summed Recent Offsets
__consumer_offsets	50	3	100	0	0	3	0	0.00	1
telegraf	60	3	100	0	0	3	0	0.00	0
```

## Deploy statuscheck configmap and consumers

    # kubectl apply -f jaws-apps-k8s-deployment/prod/statuscheck/consumer/consumerconfigmap.yaml
    # kubectl apply -f jaws-apps-k8s-deployment/prod/statuscheck/consumer/consumerdeployment.yaml

Verify consumers are showing up in kafka-manager under Cluster>Consumers. Consumers
will only show up if there is some data to consume in Kafka. If the kafka brokers
don't have any data, consumers will not show up.

## Restart HAProxy endpoints
Restart HAProxy & NGINX endpoints and check in kafka-managers whether the consumers are showing up.
```
Consumer	Type	Topics it consumes from
golang	KF	telegraf: (100% coverage, 4856 lag)
```

## Patch persistent volumes to Retain
```
# kubectl get pv
# kubectl patch pv -p '{"spec":{"persistentVolumeReclaimPolicy":"Retain"}}' pvc-372af896-6818-11e9-8d26-02c0777b771b
persistentvolume/pvc-372af896-6818-11e9-8d26-02c0777b771b patched
# ... (Repeat for all other PVs)
```

## Operations: Upgrade kafka helm installation
Change the values.yml for the helm chart and run:
```
# helm upgrade -f jaws-apps-k8s-deployment/prod/statuscheck/kafka/values_prod.yaml kafkaprod-prodvm charts/incubator/kafka/
```

## Operations: Recover from kafka lag
Sometimes if consumers are down, or there is some infrastructure issue, kafka lag can build up. It is very important to monitor Kafka lag and act quickly. It is hard to consume old data if there is too much lag.
If lag does build up, a quick fix is to update the Topic "retention.ms" value in Kafka manager UI by going to the topic. Setting it at 300000 ms (5 min) will start dropping Kafka log data older than 5 min. It takes ~ 30 min for file deletion to begin, so you'll see lag dropping quickly after 30 min.
