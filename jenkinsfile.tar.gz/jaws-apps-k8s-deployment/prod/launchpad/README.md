Deployment procedure for launchpad

## High level steps
1. Create launchpad backend deployment and service.
2. Create launchpad frontend deployment.
3. Create launchpad frontend service separately, note down Service ClusterIP if not using ingress.
4. Create launchpad ingress for kubernetes clusters which have ingress controllers running and an external load balancer like HAProxy. If ingress is not available on the cluster, use the frontend service ClusterIP and put into external load balancer (NGINX). Ensure the TLS secret with certificate and key is already created.

## First deployment

```
# git clone https://gitlab.com/jioaws/jaws-apps-k8s-deployment.git
# cd jaws-apps-k8s-deployment
(jaws-apps-k8s-deployment)# kubectl create -f prod/launchpad/lpad-deployment-be.yaml # Creates both deployment and service
(jaws-apps-k8s-deployment)# kubectl create -f prod/launchpad/lpad-deployment-fe.yaml
(jaws-apps-k8s-deployment)# kubectl create -f prod/launchpad/lpad-service-fe.yaml # Created using separate file so we don't need to delete this when doing a deployment.
(jaws-apps-k8s-deployment)# kubectl create -f prod/launchpad/lpad-ingress.yaml # Optional, only use if using ingress controllers for routing.
```

## Subsequent deployments
If using NGINX and not ingress for routing, do not delete the frontend service as the ClusterIP is hardcoded into NGINX conf on Master. Otherwise, update the ClusterIP in NGINX conf.d directory.

Note: Below procedure will have some downtime while the pods are recreated. If the container images haven't change, use kubectl apply instead of delete/create.
```
(jaws-apps-k8s-deployment)# kubectl delete -f prod/launchpad/lpad-deployment-be.yaml # Both deployment and service
(jaws-apps-k8s-deployment)# kubectl create -f prod/launchpad/lpad-deployment-be.yaml # This pulls latest images
(jaws-apps-k8s-deployment)# kubectl delete -f prod/launchpad/lpad-deployment-fe.yaml
(jaws-apps-k8s-deployment)# kubectl create -f prod/launchpad/lpad-deployment-fe.yaml # This pulls latest images
```

## Create TLS secret with certificate and key
Replace the key and cert file paths appropriately.
```
(jaws-apps-k8s-deployment)# kubectl create secret tls starjawsjio --key ssl_tls_certificates/starjawsjio.key --cert ssl_tls_certificates/starjawsjio.crt
secret/starjawsjio created
(jaws-apps-k8s-deployment)# kubectl describe secret/starjawsjio
Name:         starjawsjio
Namespace:    default
Labels:       <none>
Annotations:  <none>

Type:  kubernetes.io/tls

Data
====
tls.key:  3272 bytes
tls.crt:  2029 bytes
```
