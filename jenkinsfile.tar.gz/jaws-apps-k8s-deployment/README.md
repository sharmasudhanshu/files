# jaws-apps-k8s-deployment

jaws-apps-k8s-deployment