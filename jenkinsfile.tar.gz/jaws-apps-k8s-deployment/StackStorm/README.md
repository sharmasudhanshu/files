prerequisite for Stackstorm

1. Cinder volume storage must be configured  on k8s cluster 
2. Set default storage class to cinder volume class
3. Add stackstom helm repo
   #helm repo add stackstorm https://helm.stackstorm.com/
4. Install stackstorm helm chart
   #helm install --wait --timeout 1200 -f ss-values.yaml stackstorm/stackstorm-ha --name stackstorm
