# Kubernetes: Backups and Restore with velero

## **Kubernetes Environment Pre-Requisites**
1. Helm
2. Ingress
3. Persistent storage ( default storage class set)<br>

## **Kubernetes Clusters**
1. Cluster Z: Minio Cluster ( Kubernetes cluster for hosting minio, object storage for backup storage)
2. Cluster A: Old Cluster ( Application to migrate from )
3. Cluster B: New Cluster ( Application to migrate to )<br>

### Deploying Object based storage - minio on Cluster Z
```
jiocloud@k8s13:~$ sudo -
root@k8s13:~# helm install --name minio --namespace minio --set accessKey=minio,secretKey=minio123,persistence.size=100Gi,service.type=NodePort stable/minio
```

#### Note:  
#### 1. Login to minio with access key ``minio`` & secret key ``minio123``
#### 2. Create a bucket by name kubernetes


### Install velero client on Cluster A
```
root@k8s13:~# wget https://github.com/heptio/velero/releases/download/v1.0.0/velero-v1.0.0-linux-amd64.tar.gz
root@k8s13:~# tar -xvf velero-v1.0.0-linux-amd64.tar.gz 
root@k8s13:~# cp velero-v1.0.0-linux-amd64/velero /usr/bin
```

### Create velero credentials-velero file ( with minio access key & secret key) on Cluster A
```
root@k8s13:~# vim credentials-velero 
[default]
aws_access_key_id = minio
aws_secret_access_key = minio123
```

### Install velero server on Cluster A
```
root@k8s13:~# velero install  --provider aws --bucket kubernetes --secret-file credentials-velero --use-volume-snapshots=true --backup-location-config region=minio,s3ForcePathStyle="true",s3Url=http://10.157.249.168:32270 --snapshot-location-config region=minio,s3ForcePathStyle="true",s3Url=http://10.157.249.168:32270 --use-restic
```

### Install Sample application, i will be deploying wordpress on Cluster A
```
root@k8s13:~# helm install --name wordpress --namespace wordpress --set ingress.enabled=true,ingress.hosts[0].name=wordpress.jaws.jio.com  stable/wordpress
```

### Annoate volume to be backuped, since by default cinder storage class doesn't support snapshotting on Cluster A
```
root@k8s13:~# kubectl -n wordpress describe pod/wordpress-mariadb-0
...
Volumes:
  data:
    Type:       PersistentVolumeClaim (a reference to a PersistentVolumeClaim in the same namespace)
    ClaimName:  data-wordpress-mariadb-0
    ReadOnly:   false
  config:
    Type:      ConfigMap (a volume populated by a ConfigMap)
    Name:      wordpress-mariadb
    Optional:  false
  default-token-r6rpc:
    Type:        Secret (a volume populated by a Secret)
    SecretName:  default-token-r6rpc
    Optional:    false
...
root@k8s13:~# kubectl -n wordpress annotate pod/wordpress-mariadb-0 backup.velero.io/backup-volumes=data,config
root@k8s13:~# kubectl -n wordpress describe pod/wordpress-557589bfbc-7pzqb
...
Volumes:
  wordpress-data:
    Type:       PersistentVolumeClaim (a reference to a PersistentVolumeClaim in the same namespace)
    ClaimName:  wordpress
    ReadOnly:   false
  default-token-r6rpc:
    Type:        Secret (a volume populated by a Secret)
    SecretName:  default-token-r6rpc
    Optional:    false
...
root@k8s13:~# kubectl -n wordpress annotate pod/wordpress-557589bfbc-7pzqb backup.velero.io/backup-volumes=wordpress-data
```

### Create a backup on Cluster A
```
root@k8s13:~# velero backup create  wp-backup --snapshot-volumes --include-namespaces wordpress
```


### Install velero client on Cluster B
```
root@k8s14:~# wget https://github.com/heptio/velero/releases/download/v1.0.0/velero-v1.0.0-linux-amd64.tar.gz
root@k8s14:~# tar -xvf velero-v1.0.0-linux-amd64.tar.gz 
root@k8s14:~# cp velero-v1.0.0-linux-amd64/velero /usr/bin
```

### Create velero credentials-velero file ( with minio access key & secret key) on Cluster B
```
root@k8s14:~# vim credentials-velero 
[default]
aws_access_key_id = minio
aws_secret_access_key = minio123
```

### Install velero server on Cluster B
```
root@k8s14:~# velero install  --provider aws --bucket kubernetes --secret-file credentials-velero --use-volume-snapshots=true --backup-location-config region=minio,s3ForcePathStyle="true",s3Url=http://10.157.249.168:32270 --snapshot-location-config region=minio,s3ForcePathStyle="true",s3Url=http://10.157.249.168:32270 --use-restic
```
### Restore from backup on Cluster B
```
root@k8s13:~# velero restore create wordpress-restore --from-backup wp-backup --restore-volumes=true
```

### Wait & Verify Restore from backup on Cluster B
```
root@k8s13:~# kubectl -n wordpress get pods -w
root@k8s13:~# kubectl -n wordpress get pods
NAME                         READY   STATUS    RESTARTS   AGE
wordpress-68cd5f85c6-gr5vp   1/1     Running   0          2m29s
wordpress-mariadb-0          1/1     Running   0          2m24s
```